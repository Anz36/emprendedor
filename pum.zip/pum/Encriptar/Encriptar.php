<?php

function encriptar($clave){
    return sha1($clave);
}

?>