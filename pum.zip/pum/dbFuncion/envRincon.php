; <?php exit; ?>
MYSQL_DATABASE_NAME = "wp_emprendedor"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""