; <?php exit; ?>
MYSQL_DATABASE_NAME = "crm_emprendedor"
MYSQL_USER = "root"
MYSQL_PASSWORD = ""