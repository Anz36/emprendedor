<?php 
	include_once "../VistaAdmin/funciones.php";

 ?>